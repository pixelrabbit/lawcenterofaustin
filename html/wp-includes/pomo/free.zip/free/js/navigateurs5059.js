var version,string;
var detect = navigator.userAgent.toLowerCase();
function checkUA(str) {
	position = detect.indexOf(str) + 1;
	string = str;
	return position;
}

window.onload = function() {
	if(checkUA('msie')) {
		(detect);
		if(!version) {
			version = detect.substring(position + string.length, detect.length);
			if($.browser.msie && $.browser.version.slice() < (8))
				$('#old_browsers').css('display','block');
		}
	}
		
}