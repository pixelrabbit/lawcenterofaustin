== For Translators ==

You can use Transifex to translate User Switching: https://www.transifex.com/projects/p/user-switching/.

Alternatively, if you have created your own translation or have an update of an existing one, please send it to john@johnblackbourn.com so I can bundle it into the next release of the plugin.

Thank you!
John.
